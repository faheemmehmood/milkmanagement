
<!DOCTYPE html>
<html>
<head>
	<?php include("includes/head.php"); ?>
	<?php 
		session_start();
		if($_SESSION['username'] != ""){

		}else{
		    header("Location: index.php");
		}
	?>
</head>
<body>
	<div class="container">
		<!-- Navbar Code Started -->
		<nav class="navbar">
			<a href="main.php">
				<div class="nav_brand">
					MILKSHOP
				</div>
			</a>
			<a href="includes/logout.php">
				<div class="nav_features">
					<i class="fas fa-user"> </i> LOGOUT 
				</div>
			</a>
			<div class="clearfix"></div>
		</nav>
		<!-- ENDING NAVBAR :) -->
		<!-- STARTING THE MAIN PAGE -->
		<!-- CREATING THE CUSTOM MODULES... :) -->
		<main>
			<div class="welcome_note">
				<span style="font-size: 50px">W</span>ELCOME BACK TO MILKSHOP
			</div>
			<!-- modules -->
			<?php 
			if(isset($_GET['parameter'])){
				$parameter = $_GET['parameter'];
			}else{
				$parameter = "";
			}
			switch ($parameter) {
				case 'customers':
					include("includes/customers.php");
					break;
				case 'loan':
				include("includes/loan.php");
				break;

				case 'debits':
				include("includes/debits.php");
				break;

				case 'milk':
				include("includes/milk.php");
				break; 
				default:
					include("includes/dashboard.php");
					break;
			}
			 ?>
		</main>
	</div>
</body>
</html>
