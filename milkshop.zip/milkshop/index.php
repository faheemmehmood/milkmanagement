<!DOCTYPE html>
<html>
<head>
	<?php include("includes/head.php"); ?>
</head>
<body>
	<div class="container">
		<form class="form" method="post">
			<div class="form_header">
				LOGIN PANEL <br><br>
				<i class="fas fa-user" style="font-size: 150px"></i>
			</div>
			<table class="table">
				<?php 
					if(isset($_POST['sumbit'])){
						echo $alert;
					}else{
						$alert = "";
					}
				 ?>
				<tr>
					<td><input type="text" name="username" class="login_input" placeholder="USERNAME"></td>
				</tr>
				<tr>
					<td><input type="password" name="password" class="login_input" placeholder="PASSWORD"></td>
				</tr>
				<tr style="text-align: left; margin-left: 200px;">
					<td><input type="submit" name="submit" class="login_submit"></td>
				</tr>
			</table>
		</form>
	</div>
</body>
</html>
<?php 
	if(isset($_POST['submit'])){
		if(!empty($_POST['username']) && !empty($_POST['password'])){
            $sql = "SELECT * FROM users";
            $query = mysqli_query($conn, $sql);
            $rows = mysqli_fetch_assoc($query);
            if($rows['password'] == $_POST['password'] && $rows['username'] == $_POST['username']){
                $get_user_name = mysqli_real_escape_string($conn,$_POST['username']);
				$get_password = mysqli_real_escape_string($conn,$_POST['password']);
          		$sql = "SELECT * FROM users WHERE username = '$get_user_name' AND password = '$get_password'";
			if($result = mysqli_query($conn,$sql)){
				while($rows = mysqli_fetch_assoc($result)){
					if(mysqli_num_rows($result) == 1){
						session_start();
						$_SESSION['username'] = $get_user_name;
						$_SESSION['password'] = $get_password;
						header('Location: main.php');
					} else {
						header('Location:index.php?login_error=wrong');
					}
				}
				
			}else {
                $alert = '<div style="color: red;">EMAIL OR PASSWORD MISMATCH</div>';
			}
            }else{
               $alert =  '<div style="color: red;">EMAIL OR PASSWORD MISMATCH</div>';
            }
			
		} else {
            $alert = '<div style="color: red;">EMAIL AND PASSWORD FIELD CANNOT BE EMPTY</div>';
		}
	}

 ?>