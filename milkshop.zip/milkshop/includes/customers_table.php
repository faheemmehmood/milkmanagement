<?php 
if(isset($_POST['submit'])){
	$name = $_POST['name'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$cnic = $_POST['cnic'];
	$t_address = $_POST['t_address'];
	$p_address = $_POST['p_address'];
	$user_type = $_POST['user_type'];
	$date = date('Y-m-d');
	$ins_sql = "INSERT INTO customers (name, phone, email, cnic, address, p_address, user_type, reg_date) VALUES ('$name', '$phone', '$email', '$cnic', '$t_address', '$p_address', '$user_type', '$date')";
	$ins_query = mysqli_query($conn, $ins_sql);
	if($ins_query){
		$sel_sql = "SELECT * FROM customers WHERE name = '$name'";
		$sel_query = mysqli_query($conn, $sel_sql);
		if(mysqli_num_rows($sel_query) == 1) {
			$s_row = mysqli_fetch_assoc($sel_query);
			$ins_sql = "INSERT INTO loan (customer_id, customer_name, loan) VALUES ('$s_row[id]', '$s_row[name], '0')";
			$ins_query = mysqli_query($conn, $ins_sql);
		}
	}
	
	if($ins_query){
		$status = '<div style="width:100%; padding: 5px 0;text-align:center; color:white; background: green">A NEW CUSTOMER HAS BEEN ADDED NAMED: <b>'.$_POST['name'].'</b></div>';
	}else{
		$status = '<div style="width:100%; padding: 5pxvfxc 0;text-align:center; color:white; background: red">UNFORTUNATELY CUSTOMER CANNOT BE ADDED</div>';
	}
	

}else{
	$status = "";
}
echo $status;

 	?>
<?php 
	if(isset($_GET['new_user'])){
		$status = '<div style="width:100%; padding: 5px 0; color:white; background: green">YOU JUST ADDED A NEW USER</div>';
	}else{
		$status = "";
	}
	echo $status;
	$sel_sql = "SELECT * FROM customers WHERE user_type = 'Monthly Basis'";
	$sel_query = mysqli_query($conn, $sel_sql);
	$count_user1 = mysqli_num_rows($sel_query);
	$sel_sql = "SELECT * FROM customers WHERE user_type = 'Daily Basis'";
	$sel_query = mysqli_query($conn, $sel_sql);
	$count_user2 = mysqli_num_rows($sel_query);
	$count_all = $count_user1 + $count_user2;
	if(isset($_POST['download_data'])){ 
//export.php  
$output = '';
 $query = "SELECT * FROM customers";
 $result = mysqli_query($conn, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
        <tr>  
			<th>Name</th>  
		    <th>Address</th>  
		    <th>Phone</th>  
	    </tr>
  ';
  while($row = mysqli_fetch_array($result)){
   $output .= '
    <tr>  
       <td>'.$row["name"].'</td>  
       <td>'.$row["address"].'</td>  
       <td>'.$row["phone"].'</td>
    </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }
}

 ?>

<div style="margin-top: 30px;"></div>
<form method="post" >
	<input style="padding: 5px 10px;" type="text" name="search_filter" placeholder="Search Here">
	<input type="submit" style="padding: 5px;" name="search_submit">
	<input type="submit" style="padding: 5px;" name="download_data" value="Download">
</form>



<div style="margin-top: 30px;"></div>

<a href="main.php?parameter=customers&user_type=Monthly_Basis" class="btn_m blue">Monthly Basis <?php echo $count_user1; ?></a>
<a href="main.php?parameter=customers&user_type=Daily_Basis" class="btn_m red">Daily Basis <?php echo $count_user2; ?></a>
<div style="margin-top: 30px;"></div>
<table class="table_show">
	<tr>	
		<th>ID</th>
		<th>Full Name</th>
		<th>Phone</th>
		<th>Address</th>
	</tr>
	
	<?php 
	
if(isset($_GET['user_type'])){
if($_GET['user_type'] == 'Monthly_Basis'){
	$sel_sql = "SELECT * FROM customers WHERE user_type = 'Monthly Basis'";
	$sel_query = mysqli_query($conn, $sel_sql);
	echo '<h2 style="margin: 5px">Monthly Basis</h2>';
	while($row = mysqli_fetch_assoc($sel_query)){
	echo 
		'<tr>
			<td>'.$row['id'].'</td>
			<td>'.$row['name'].'</td>
			<td>'.$row['phone'].'</td>
			<td>'.$row['address'].'</td>
			<td><a href="main.php?parameter=customers&add_user=details&id='.$row['id'].'">DETAILS</a></td>
		</tr>';		
}
}elseif($_GET['user_type'] == 'Daily_Basis'){
echo '<h2 style="margin:5px;">Daily Basis</h2>';
		$sel_sql = "SELECT * FROM customers WHERE user_type = 'Daily Basis'";
		$sel_query = mysqli_query($conn, $sel_sql);
		while($row = mysqli_fetch_assoc($sel_query)){
		echo 
			'<tr>
				<td>'.$row['id'].'</td>
				<td>'.$row['name'].'</td>
				<td>'.$row['phone'].'</td>
				<td>'.$row['address'].'</td>
				<td><a href="main.php?parameter=customers&add_user=details&id='.$row['id'].'">DETAILS</a></td>
			</tr>';		
}


}
}elseif(isset($_POST['search_submit'])){
$search_filter = $_POST['search_filter'];
$search_query = "SELECT * FROM customers WHERE name LIKE '%{$search_filter}%' OR phone LIKE '%{$search_filter}%' OR address LIKE '%{$search_filter}%'";
$search_sql = mysqli_query($conn, $search_query);
	while($row = mysqli_fetch_assoc($search_sql)){
		echo 
			'<tr>
				<td>'.$row['id'].'</td>
				<td>'.$row['name'].'</td>
				<td>'.$row['phone'].'</td>
				<td>'.$row['address'].'</td>
				<td><a href="main.php?parameter=customers&add_user=details&id='.$row['id'].'">DETAILS</a></td>
			</tr>';		
	}

}else{
	$sel_sql = "SELECT * FROM customers";
	$sel_query = mysqli_query($conn, $sel_sql);
	while($row = mysqli_fetch_assoc($sel_query)){
	echo 
		'<tr>
			<td>'.$row['id'].'</td>
			<td>'.$row['name'].'</td>
			<td>'.$row['phone'].'</td>
			<td>'.$row['address'].'</td>
			<td><a href="main.php?parameter=customers&add_user=details&id='.$row['id'].'">DETAILS</a></td>
		</tr>';		
}
}

?>

 <?php  
 //export.php  
 if(isset($_POST["create_word"]))  {  
      if(empty($_POST["heading"]) || empty($_POST["description"]))  {  
           echo '<script>alert("Both Fields are required")</script>';  
           echo '<script>window.location = "index.php"</script>';  
      }  
      else  
      {  
           
      }  
 }  
 ?>  
</table>