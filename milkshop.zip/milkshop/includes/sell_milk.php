<form class="add_user_form" method="post" role="form" >
	<?php 
		if(isset($_POST['submit'])){


			$sel_sql = "SELECT * FROM milk WHERE id = 1";
			$sel_query = mysqli_query($conn, $sel_sql);
			$m_row = mysqli_fetch_assoc($sel_query);

			$milk = $m_row['milk'];
			$new_milk = $milk - $_POST['milk'];
			
			$update_sql = "UPDATE milk SET milk = '$new_milk' WHERE id = 1";
			$update_query = mysqli_query($conn, $update_sql);

			$milk = $_POST['milk'];
			$p_amount = $_POST['p_amount'];
			$price = $_POST['milk'] * 100;
			$date = date('Y-m-d');
			$customer_id = $_POST['user_id'];
			$return = $p_amount - $price;


			if($p_amount >= $price ){
				$p_amount = $price;
				$ins_sql = "INSERT INTO sale_milk (customer_id, milk_given, price, paid_amount, date) VALUES ('$_POST[user_id]', '$_POST[milk]', '$price', $p_amount,'$date')";

				$ins_query = mysqli_query($conn, $ins_sql);
				if($ins_query){
					$status = '<div style="width:100%; padding: 5px 0;text-align:center; color:white; background: green; font-weight: 700">SUCCESS: PLEASE RETURN : '.$return.' RUPEES</div>';
				}else{
					$status = '<div style="width:100%; padding: 5px 0;text-align:center; color:white; background: red; font-weight: 700">Unfortunately We are not able to add the data</div>';
				}

			}else{
				$ins_sql = "INSERT INTO sale_milk (customer_id, milk_given, price, paid_amount, date) VALUES ('$_POST[user_id]', '$_POST[milk]', '$price', $p_amount,'$date')";

				$sel_sql = "SELECT * FROM loan WHERE customer_id = '$_POST[user_id]'";

				$sel_query = mysqli_query($conn, $sel_sql);

				if(mysqli_num_rows($sel_query) == 0){

					$sel_from = "SELECT * FROM users WHERE id = '$_POST[user_id]'";

					$sel_submit = mysqli_query($conn, $sel_from);

					$q_row = mysqli_fetch_assoc($sel_submit);

					$name = $q_row['name'];

					$create_loan = "INSERT INTO loan (customer_id, loan) VALUES ('$_POST[user_id]', '$name', '0')";

					$create_query = mysqli_query($conn, $create_loan);
					$row = mysqli_fetch_assoc($sel_query);

					$l_loan = $price - $p_amount;

					$loan = $row['loan']; 

					$update_loan = $l_loan + $loan;

					$ins_query = mysqli_query($conn, $ins_sql);

					$loan_sql = "UPDATE loan SET loan = '$update_loan' WHERE customer_id = '$_POST[user_id]' ";

					$loan_query = mysqli_query($conn, $loan_sql);

					$status = '<div style="width:100%; padding: 5px 0;text-align:center; color:white; background: red; font-weight: 700">USER HAD THE LOAN OF '.$loan.' RS AFTER THIS IT IS = '.$update_loan.' RS</div>';
				}else{


					$row = mysqli_fetch_assoc($sel_query);

					$l_loan = $price - $p_amount;
					$loan = $row['loan']; 
					$update_loan = $l_loan + $loan;
					$ins_query = mysqli_query($conn, $ins_sql);
					$loan_sql = "UPDATE loan SET loan = '$update_loan' WHERE customer_id = '$_POST[user_id]' ";
					$loan_query = mysqli_query($conn, $loan_sql);
					$customer_sql = "SELECT * FROM customers WHERE id = '$customer_id' AND user_type = 'Monthly Basis'";
					$customer_query = mysqli_query($conn, $customer_sql);
					if(mysqli_num_rows($customer_query) == 1){
						$row = mysqli_fetch_assoc($customer_query);
						$reg = $row['reg_date'];
						$today = Date("Y-m-d");
						$earlier = new DateTime($today);
						$later = new DateTime($reg);

						$diff = $later->diff($earlier)->format("%a");
						$month = 30 - $diff;

						$status = '<div style="width:100%; padding: 5px 0;text-align:center; color:white; background: red; font-weight: 700">REMAINING DAYS FOR BILL:'.$month.' DAYS <br> CURRENT BILL: '.$update_loan.'</div>';

					}else{
						$status = '<div style="width:100%; padding: 5px 0;text-align:center; color:white; background: red; font-weight: 700">USER HAD THE LOAN OF '.$loan.' RS AFTER THIS IT IS = '.$update_loan.' RS</div>';
					}

					
				}

				} 

				
			}else{
			$status = '<div style="width:100%; padding: 5px 0;text-align:center; color:white; background: blue; font-weight: 700">Please Fill The Information Below</div>';
			$loan = '';
		}
		echo $status;

 	?>
 	<?php 
 	// 	$sel_sql = "SELECT * FROM sale_milk WHERE customer_id = '3'";
 	// 	$result = mysqli_query($conn, $sel_sql);
 	// 	$query = "SELECT * FROM sale_milk";
		// $query_run = mysqli_query($conn, $query);

		// $qty= 0;
		// while ($num = mysqli_fetch_assoc ($query_run)) {
		//     $qty += $num['price'];
		// }
		// echo $qty;

 	 ?>
	<div class="form_table">
		<table>
			<tr>
				<td><select class="add_user_input" name="user_id" required>
					<option value="">Select Customer Name</option>
					<?php 
						$sel_sql = "SELECT * FROM customers";
						$sel_query = mysqli_query($conn, $sel_sql);
						while($row =mysqli_fetch_assoc($sel_query)){
							echo '<option value="'.$row['id'].'">'.$row['name'].'</option>';	
						}
					 ?>
				</select></td>
			</tr>
			<tr>
				<td>
					<input type="number" class="add_user_input" style="width: 50px" name="milk" required>
					<span style=""><b>KG</b></span>
				</td>
			</tr>
			<tr>
				<td>
					<input type="number" class="add_user_input" style="width: 50px" name="p_amount" required>
					<span style=""><b>RS</b></span>
				</td>
				
				<td><input type="submit" name="submit" class="add_user_btn"></td>
			</tr>
		</table>
	</div>
</form>
