
<table style="padding-top: 30px;" class="table_show float_left">
	<tr>	
		<th>ID</th>
		<th>Full Name</th>
	</tr>
	
	<?php 
		$sel_sql = "SELECT * FROM customers WHERE user_type = 'Daily Basis'";
		$sel_query = mysqli_query($conn, $sel_sql);
		while($row = mysqli_fetch_assoc($sel_query)){
		echo 
			'<tr>
				<td>'.$row['id'].'</td>
				<td>'.$row['name'].'</td>
				<td><a href="?parameter=loan&details='.$row['id'].'">SEE LOAN</td>';
				
			'</tr>';		
		}
		
	 ?>
</table>
<?php 

	if(isset($_GET['details'])){
			$customer_id = $_GET['details'];

			$sel_sql = "SELECT * FROM loan WHERE customer_id = '$customer_id'";
			$sel_query = mysqli_query($conn, $sel_sql);
			$row = mysqli_fetch_assoc($sel_query);
			$loan = $row['loan'];
			echo '<table style="padding-top: 30px;" class="table_show float_left">
						<tr>=
							<td style="font-weight: 700; color: black padding: 15px;">'.$loan.' RS</td>
						</tr>';
						if($loan != 0){
								echo '<form method="post">
								<tr><td><input type="number" name="paid_amount" class="add_user_input" placeholder="PAY LOAN"></td></tr>
								<tr><td><input type="submit" name="submit" ></td></tr>
							</form>';

							if(isset($_POST['submit'])){

								$paid = $loan - $_POST['paid_amount'];

								$update_sql = "UPDATE loan SET loan = '$paid' WHERE customer_id = '$customer_id'";

								$update_query = mysqli_query($conn, $update_sql);
							}
						}
						
					echo '</table>';


	}
 ?>
