<div class="modules">
	<div class="buttons_area">
		<?php 
			$sel_sql = "SELECT * FROM customers";
			$sel_query = mysqli_query($conn, $sel_sql);
			$count_user = mysqli_num_rows($sel_query);
		 ?>
		<a href="main.php" class="btn_m red">MAIN PAGE</a> 
		<a href="main.php?parameter=milk" class="btn_m green">ALL SUPPLIERS <span style="color:black"></a> </span>
		<a href="main.php?parameter=milk&add_user=add" class="btn_m orange">ADD SUPPLIER</a> 
		<a href="main.php?parameter=milk&add_user=get" class="btn_m blue">GET MILK</a> 
	</div>
	<?php 
		if(isset($_GET['add_user'])){
			$get = $_GET['add_user'];
		}else{
			$get = "";
		}
		switch ($get) {
			case 'add':
				include("add_supplier.php");
				break;
			case 'get':
				include("get_milk.php");
				break;
			default:
				include("suppliers_table.php");
				break;
		}

	 ?>
	
</div>
 