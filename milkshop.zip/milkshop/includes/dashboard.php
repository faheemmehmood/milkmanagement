
<div class="modules">
	<a href="main.php?parameter=customers">
		<div class="module_item">
			<div class="orange module_item_top">
				<div class="module_item_top_left">
					<i class="fas fa-user" style="font-size: 90px; color: white; margin: 10px;"></i>
				</div>
				<div class="module_item_top_right">
					CUSTOMERS
					<?php 
						$sel_sql = "SELECT * FROM customers";
						$sel_query = mysqli_query($conn, $sel_sql);
						$count_a_user = mysqli_num_rows($sel_query);

					 ?>
					<div style="font-size:70px"><?php echo $count_a_user; ?></div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="module_item_bottom">
				VIEW DETAILS
			</div>
		</div>
	</a>
	<a href="main.php?parameter=loan">
		<div class="module_item">
			<div class="module_item_top blue">
				<div class="module_item_top_left">
					<i class="fas fa-angle-double-down" style="font-size: 90px; color: white; margin: 10px;"></i>
				</div>
				<div class="module_item_top_right">
					DAILY CREDITS

					<?php 
						$sel_sql = "SELECT * FROM customers WHERE user_type = 'Daily Basis'";
						$sel_query = mysqli_query($conn, $sel_sql);
						$count_d_users = mysqli_num_rows($sel_query);
					 ?>
					<div style="font-size:70px"><?php echo $count_d_users; ?><span style="font-size: 17px"></span></div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="module_item_bottom">
				VIEW DETAILS
			</div>
		</div>
		
	</a>
	<a href="main.php?parameter=debits">
		<div class="module_item">
			<div class="module_item_top red">
				<div class="module_item_top_left">
					<i class="fas fa-address-book" style="font-size: 90px; color: white; margin: 10px;"></i>
				</div>
				<div class="module_item_top_right">
					MONTHLY
					<?php 
							$sel_sql = "SELECT * FROM customers WHERE user_type = 'Monthly Basis'";
							$sel_query = mysqli_query($conn, $sel_sql);
							$count_user1 = mysqli_num_rows($sel_query);

					 ?>
					<div style="font-size:70px"><?php echo $count_user1; ?><span style="font-size: 14px"></span></div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="module_item_bottom">
				VIEW DETAILS
			</div>
		</div>
	</a>
	<a href="main.php?parameter=milk">
		<div class="module_item">
			<div class="module_item_top green">
				<div class="module_item_top_left">
					<i class="fas fa-align-justify" style="font-size: 90px; color: white; margin: 10px;"></i>
				</div>
				<div class="module_item_top_right">
					<?php 
						$sel_sql = "SELECT * FROM milk WHERE id = 1";
						$sel_query = mysqli_query($conn, $sel_sql);
						$row = mysqli_fetch_assoc($sel_query);
						$milk = $row['milk'];
					 ?>
					MILK 
					<div style="font-size:70px"><?php echo $milk; ?><span style="font-size: 17px">KG</span></div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="module_item_bottom">
				VIEW DETAILS
			</div>
		</div>
	</a>
	<div class="clearfix"></div>
</div>