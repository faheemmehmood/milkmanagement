<table style="padding-top: 30px;" class="table_show float_left">
	<tr>	
		<th>ID</th>
		<th>Full Name</th>
		<th>Days Remaining</th>
		<th>CURRENT BILL</th>
	</tr>
	
	<?php 
		$sel_sql = "SELECT * FROM customers WHERE user_type = 'Monthly Basis'";
		$sel_query = mysqli_query($conn, $sel_sql);
		while($row = mysqli_fetch_assoc($sel_query)){
			$reg = $row['reg_date'];                                                         
			$today = Date("Y-m-d");
			$earlier = new DateTime($today);
			$later = new DateTime($reg);
			$loan_sql = "SELECT * FROM loan WHERE customer_id = '$row[id]'";
			$loan_query = mysqli_query($conn, $loan_sql);
			$l_row = mysqli_fetch_assoc($loan_query);
			$loan = $l_row['loan'];


			$diff = $later->diff($earlier)->format("%a");
			$month = 30 - $diff;
		echo 
			'<tr>

				<td>'.$row['id'].'</td>
				<td>'.$row['name'].'</td>
				<td>'.$month.' DAYS</td>
				<td>'.$loan.' RS</td>';

				if($month <= 0){
					echo '<td><a href="main.php?parameter=debits&customer_id='.$row['id'].'">PAY BILL</a></td>';

				}
				
			echo '</tr>';		
		}
		
	 ?>
</table>
<?php 

	if(isset($_GET['custoemr_id'])){
			$customer_id = $_GET['customer_id'];

			$sel_sql = "SELECT * FROM loan WHERE customer_id = '$customer_id'";
			$sel_query = mysqli_query($conn, $sel_sql);
			$row = mysqli_fetch_assoc($sel_query);
			$loan = $row['loan'];
			echo '<table style="padding-top: 30px;" class="table_show float_left">
						<tr>=
							<td style="font-weight: 700; color: black padding: 15px;">'.$loan.' RS</td>
						</tr>';
						if($loan != 0){
								echo '<form method="post">
								<tr><td><input type="number" name="paid_amount" class="add_user_input" placeholder="PAY LOAN"></td></tr>
								<tr><td><input type="submit" name="submit" ></td></tr>
							</form>';

							if(isset($_POST['submit'])){

								$paid = $loan - $_POST['paid_amount'];

								$update_sql = "UPDATE loan SET loan = '$paid' WHERE customer_id = '$customer_id'";

								$update_query = mysqli_query($conn, $update_sql);
							}
						}
						
					echo '</table>';


	}
 ?>
