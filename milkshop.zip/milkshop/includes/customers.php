<?php 
	$sql = "SELECT * FROM customers";
	$query = mysqli_query($conn, $sql);

 ?>
<div class="modules">
	<div class="buttons_area">
		<?php 
			$sel_sql = "SELECT * FROM customers";
			$sel_query = mysqli_query($conn, $sql);
			$count_user = mysqli_num_rows($sel_query);
		 ?>
		<a href="main.php" class="btn_m red">MAIN PAGE</a> 
		<a href="main.php?parameter=customers" class="btn_m green">ALL CUSTOMERS <span style="color:black"><b><?php echo $count_user; ?></b></a> </span>
		<a href="main.php?parameter=customers&add_user=add" class="btn_m orange">ADD CUSTOMER</a> 
		<a href="main.php?parameter=customers&add_user=sell" class="btn_m blue">SELL MILK</a> 
	</div>
	<?php 
		if(isset($_GET['add_user'])){
			$get = $_GET['add_user'];
		}else{
			$get = "";
		}
		switch ($get) {
			case 'add':
				include("add_user.php");
				break;
			case 'sell':
				include("sell_milk.php");
				break;
			case 'details':
				include("details_bill.php");
				break;
			default:
				include("customers_table.php");
				break;
		}

	 ?>
	
</div>
 