<?php 
		if(isset($_POST['submit'])){
			$date = date('Y-m-d h:i:s');
			$ins_sql = "INSERT INTO suppliers (name, phone, email, cnic, address, p_address, user_type, reg_date) VALUES ('$_POST[name]', '$_POST[phone]', '$_POST[email]', '$_POST[cnic]', '$_POST[t_address]', '$_POST[p_address]', '$_POST[user_type]', '$date')";
			if(mysqli_query($conn, $ins_sql)){
				header("Location: main.php?parameter=customers&new_user=true");
			}
			
			

		}else{
			$status = "";
		}

 ?>
<form class="add_user_form" method="post" role="form" action="main.php?parameter=milk&new_user=true">
	

	<div class="form_table">
		<table>
			<tr>
				<td><input type="text" name="name" placeholder="Full Name" class="add_user_input" required></td>
				<td><input type="number" name="phone" placeholder="Phone" class="add_user_input" required></td>
				<td><input type="number" name="cnic" placeholder="CNIC" class="add_user_input" required></td>
				<td><input type="email" name="email" placeholder="Email Address" class="add_user_input" required></td>
			</tr>
			<tr>
				<td colspan="2"><input type="text" name="t_address" placeholder="Address" class="add_user_input_long" required></td>
				<td colspan="2"><input type="text" name="p_address" placeholder="Permanent Address" class="add_user_input_long" required></td>
			</tr>
			<tr>
				<td><select class="add_user_input" required name="user_type">
					<option value="">Payment</option>
					<option value="Daily Basis">Daily Basis</option>
					<option value="Monthly Basis">Monthly Basis</option>
					<option value="Weekly Basis">Weekly Basis</option>
				</select></td>
				<td><input type="submit" name="submit" class="add_user_btn"></td>
			</tr>
		</table>
	</div>
</form>
