<form class="add_user_form" method="post" role="form" >
<div class="form_table">
		<table>
			<tr>
				<td><select class="add_user_input" name="user_id" required>
					<option value="">Select Supplier Name</option>
					<?php 
						$sel_sql = "SELECT * FROM suppliers";
						$sel_query = mysqli_query($conn, $sel_sql);
						while($row =mysqli_fetch_assoc($sel_query)){
							echo '<option value="'.$row['id'].'">'.$row['name'].'</option>';	
						}
					 ?>
				</select></td>
			</tr>
			<tr>
				<td>
					<input type="number" class="add_user_input" style="width: 50px" name="milk" required>
					<span style=""><b>KG</b></span>
				</td>
			</tr>
			<tr>
				<td><input type="submit" name="submit" class="add_user_btn"></td>
			</tr>
			<?php 
				if(isset($_POST['submit'])){
					$sel_sql = "SELECT * FROM milk WHERE id = 1";
					$sel_query = mysqli_query($conn, $sel_sql);
					$row = mysqli_fetch_assoc($sel_query);
					$milk = $row['milk'];
					$new_milk = $_POST['milk'] + $milk;
					echo $new_milk;
					$ins_sql = "UPDATE milk SET milk = '$new_milk'";
					$ins_query = mysqli_query($conn, $ins_sql);
				}
			 ?>
		</table>
	</div>
</form>