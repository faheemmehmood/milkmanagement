<table class="table_show float_left">
	<?php
	if(isset($_GET['download_id'])){
		$id = $_GET['download_id'];
		$data_sql = "SELECT * FROM customers WHERE id = '$id'";
		$data_query = mysqli_query($conn, $data_sql);
		$row = mysqli_fetch_assoc($data_query);

		header("Content-type: application/vnd.ms-word");  
           header("Content-Disposition: attachment;Filename=".rand().".doc");  
           header("Pragma: no-cache");  
           header("Expires: 0");  
           echo '<h1>'.$row['name'].'</h1>';  
           echo '<p>Phone: '.$row['phone'].'</p>';
           echo '<p>Email: '.$row['email'].'</p>';
           echo '<p>Address: '.$row['address'].'</p>';  
           echo '<p>User Type: '.$row['user_type'].'</p>';  
           echo '<p>Date: '.$row['user_type'].'</p>';  
	}
	if(isset($_GET['id'])){ 

		$sel_sql = "SELECT * FROM customers WHERE id = '$_GET[id]'";
		$sel_query = mysqli_query($conn, $sel_sql);
		$row = mysqli_fetch_array($sel_query);
		$id = $row['id'];
		$name = $row['name'];
		$phone = $row['phone'];
		$email = $row['email'];
		$cnic = $row['address'];
		$payment = $row['user_type'];
		$date = $row['reg_date'];
	}

		echo '<tr>
				<th>ID</th>
				<td>'.$id.'</td>
			</tr>
			<tr>
				<th>Name</th>
				<td>'.$name.'</td>
			</tr>
			<tr>
				<th>Phone</th>
				<td>'.$phone.'</td>
			</tr>
			<tr>
				<th>Email</th>
				<td>'.$cnic.'</td>
			</tr>
			<tr>
				<th>Payment</th>
				<td>'.$payment.'</td>
			</tr>
			<tr>
				<th>Registration Date</th>
				<td>'.$date.'</td>
			</tr>
			<tr>
				<th></th>
				<td><a href="main.php?parameter=customers&add_user=details&id='.$id.'&details_id='.$id.'" style="color: white; padding: 3px;" class="blue">BILLING DETAILS</a><a href="main.php?parameter=customers&add_user=details&id='.$id.'&details_id='.$id.'&download_id='.$id.'" style="color: white; padding: 3px;" class="orange">Export to WORD</a></td>
			</tr>
			';


	 ?>
</table>
<table class="table_show float_left">
	<?php
	if(isset($_GET['id'])){ 

		$sel_sql = "SELECT * FROM customers WHERE id = '$_GET[id]'";
		$sel_query = mysqli_query($conn, $sel_sql);
		$row = mysqli_fetch_array($sel_query);
		$id = $row['id'];
		$name = $row['name'];
		$phone = $row['phone'];
		$email = $row['email'];
		$cnic = $row['address'];
		$payment = $row['user_type'];
		$date = $row['reg_date'];
	}

	?>
	
	<?php 
		if(isset($_GET['details_id'])){
				$sel_sql = "SELECT * FROM sale_milk WHERE customer_id = '$_GET[details_id]'";
				$sel_query = mysqli_query($conn, $sel_sql);
				echo '<tr style="text-align: left;">
							<th>Date</th>
							<th>MILK GIVEN</th>
							<th>Price</th>						
							<th>PAID AMOUNT</th>
						</tr>';
				if(mysqli_num_rows($sel_query) < 1){
					echo '<tr><td colspan="4" style="color: red">NO RECORD TO SHOW</td></tr>';
				}else{
					while($row = mysqli_fetch_assoc($sel_query)){
					echo '
						<tr>
							<td>'.$row['date'].'</td>
							<td>'.$row['milk_given'].' KG</td>
							<td>'.$row['price'].' Rs.</td>
							<td>'.$row['paid_amount'].' RS</td>
						</tr>
						
					';
				}
			}
				
				

			}
		


	 ?>
</table>
<div class="clearfix"></div>
<?php
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="sample.csv"');
$data = array('aaa,bbb,ccc,dddd','123,456,789',"aaa","bbb");

$fp = fopen('php://output', 'wb');
foreach ( $data as $line ) {
    $val = explode(",", $line);
    fputcsv($fp, $val);
}
fclose($fp);



?>