<?php 
		if(isset($_POST['submit'])){
			$name = $_POST['name'];
			$phone = $_POST['phone'];
			$email = $_POST['email'];
			$cnic = $_POST['cnic'];
			$t_address = $_POST['t_address'];
			$p_address = $_POST['p_address'];
			$user_type = $_POST['user_type'];
			$date = date('Y-m-d');
			$ins_sql = "INSERT INTO suppliers (name, phone, email, cnic, address, p_address, user_type, reg_date) VALUES ('$name', '$phone', '$email', '$cnic', '$t_address', '$p_address', '$user_type', '$date')";
			$ins_query = mysqli_query($conn, $ins_sql);
			
			if($ins_query){
				$status = '<div style="width:100%; padding: 5px 0;text-align:center; color:white; background: green">A NEW CUSTOMER HAS BEEN ADDED NAMED: <b>'.$_POST['name'].'</b></div>';
			}else{
				$status = '<div style="width:100%; padding: 5pxvfxc 0;text-align:center; color:white; background: red">UNFORTUNATELY CUSTOMER CANNOT BE ADDED</div>';
			}
			

		}else{
			$status = "";
		}
		echo $status;

 	?>
<?php 
	if(isset($_GET['new_user'])){
		$status = '<div style="width:100%; padding: 5px 0; color:white; background: green">YOU JUST ADDED A NEW USER</div>';
	}else{
		$status = "";
	}
	echo $status;

 ?>
<table class="table_show">
	<tr>	
		<th>ID</th>
		<th>Full Name</th>
		<th>Phone</th>
		<th>Address</th>
	</tr>
	
	<?php 
	
		$sel_sql = "SELECT * FROM suppliers";
		$sel_query = mysqli_query($conn, $sel_sql);
		while($row = mysqli_fetch_assoc($sel_query)){
		echo 
			'<tr>
				<td>'.$row['id'].'</td>
				<td>'.$row['name'].'</td>
				<td>'.$row['phone'].'</td>
				<td>'.$row['address'].'</td>
				<td><a href="main.php?parameter=customers&add_user=details&id='.$row['id'].'">DETAILS</a></td>
			</tr>';		
		}
		
	 ?>
</table>